﻿namespace Coffe.Classes
{
    public class Sede
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
    }
}
