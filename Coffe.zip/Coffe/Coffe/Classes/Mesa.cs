﻿namespace Coffe.Classes
{
    public class Mesa
    {
        public int id { get; set; }
        public int numero_mesa { get; set; }
        public string estado { get; set; } // "Disponible" o "Ocupada"
    }
}

